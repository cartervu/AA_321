#!/bin/bash

mv *alpha_20* alpha+20
mv *alpha20* alpha+20
mv *pos_20* alpha+20
mv *pos20* alpha+20
mv *+20* alpha+20

mv *alpha_18* alpha+18
mv *alpha18* alpha+18
mv *pos_18* alpha+18
mv *pos18* alpha+18
mv *+18* alpha+18

mv *alpha_16* alpha+16
mv *alpha16* alpha+16
mv *pos_16* alpha+16
mv *pos16* alpha+16
mv *+16* alpha+16

mv *alpha_14* alpha+14
mv *alpha14* alpha+14
mv *pos_14* alpha+14
mv *pos14* alpha+14
mv *+14* alpha+14

mv *alpha_12* alpha+12
mv *alpha12* alpha+12
mv *pos_12* alpha+12
mv *pos12* alpha+12
mv *+12* alpha+12

mv *alpha_10* alpha+10
mv *alpha10* alpha+10
mv *pos_10* alpha+10
mv *pos10* alpha+10
mv *+10* alpha+10

mv *alpha_8* alpha+8
mv *alpha8* alpha+8
mv *pos_8* alpha+8
mv *pos8* alpha+8
mv *+8* alpha+8

mv *alpha_6* alpha+6
mv *alpha6* alpha+6
mv *pos_6* alpha+6
mv *pos6* alpha+6
mv *+6* alpha+6

mv *alpha_4* alpha+4
mv *alpha4* alpha+4
mv *pos_4* alpha+4
mv *pos4* alpha+4
mv *+4* alpha+4

mv *alpha_2* alpha+2
mv *alpha2* alpha+2
mv *pos_2* alpha+2
mv *pos2* alpha+2
mv *+2* alpha+2

mv *alpha-zero* alpha+0
mv *alpha0* alpha+0
mv *alpha-0* alpha+0
mv *a_0* alpha+0
mv *+0* alpha+0

mv *neg_2* alpha-2
mv *neg2* alpha-2
mv *-2* alpha-2

mv *neg_4* alpha-4
mv *neg4* alpha-4
mv *-4* alpha-4
